from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                
                # Get the 'next' parameter for proper redirection
                next_url = request.GET.get('next')
                
                # Role-based redirection logic
                if hasattr(user, 'profile'):
                    if user.profile.role == 'admin':
                        return redirect('/admin/')
                    elif user.profile.role == 'manager':
                        return redirect('/dashboard/')
                    else:
                        return redirect('/personal/')
                else:
                    # Fallback for users without profiles
                    return redirect(next_url if next_url else '/dashboard/')
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    
    return render(request, 'accounts/login.html', {'form': form})

@login_required
def dashboard_view(request):
    """Dashboard for manager users"""
    return render(request, 'accounts/dashboard.html', {
        'user': request.user,
        'role': getattr(request.user.profile, 'role', 'unknown') if hasattr(request.user, 'profile') else 'unknown'
    })

@login_required
def personal_dashboard(request):
    """Dashboard for personal users"""
    return render(request, 'accounts/personal.html', {
        'user': request.user,
        'role': getattr(request.user.profile, 'role', 'unknown') if hasattr(request.user, 'profile') else 'unknown'
    })

def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return redirect('/accounts/login/')
