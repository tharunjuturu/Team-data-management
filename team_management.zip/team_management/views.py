from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required

def home_redirect(request):
    """
    Smart home view that redirects based on authentication status
    without creating redirect loops
    """
    if not request.user.is_authenticated:
        return redirect('/accounts/login/')
    
    # For authenticated users, redirect to their appropriate dashboard
    if hasattr(request.user, 'profile'):
        if request.user.profile.role == 'admin':
            return redirect('/admin/')
        elif request.user.profile.role == 'manager':
            return redirect('/dashboard/')
        else:
            return redirect('/personal/')
    
    # Fallback for users without profiles
    return redirect('/dashboard/')

@login_required
def dashboard_home(request):
    """
    Alternative: A unified dashboard that shows different content based on role
    """
    user_role = 'unknown'
    if hasattr(request.user, 'profile'):
        user_role = request.user.profile.role
    
    context = {
        'user': request.user,
        'user_role': user_role,
    }
    return render(request, 'home.html', context)
