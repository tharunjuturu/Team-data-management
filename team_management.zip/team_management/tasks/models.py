from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone


class Task(models.Model):
    class Status(models.TextChoices):
        TODO        = 'todo',  'To Do'
        IN_PROGRESS = 'prog',  'In Progress'
        UAT         = 'uat',   'In UAT'
        DONE        = 'done',  'Delivered'
        BLOCKED     = 'blck',  'Blocked'

    # NEW BUSINESS COLUMNS
    function_name      = models.CharField(max_length=150, default='Untitled Function')
    task_type          = models.CharField(max_length=100,  default='General')
    collab_responsible = models.CharField(max_length=100,  default='TBD')

    total_fts     = models.PositiveIntegerField(default=0)
    completed_fts = models.PositiveIntegerField(default=0)

    start_date    = models.DateField(default=timezone.now)
    delivery_date = models.DateField(null=True, blank=True)
    remarks       = models.TextField(blank=True, default='')

    # ORIGINAL COLUMNS (kept for compatibility)
    title       = models.CharField(max_length=200, default='Task')
    description = models.TextField(blank=True)
    assignee    = models.ForeignKey(User, related_name='tasks',
                                    on_delete=models.CASCADE)
    status      = models.CharField(max_length=5,
                                   choices=Status.choices,
                                   default=Status.TODO)

    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)
    due_date    = models.DateField(null=True, blank=True)   # legacy field

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.id} – {self.function_name}"


class DailyUpdate(models.Model):
    task              = models.ForeignKey(Task, related_name='updates',
                                          on_delete=models.CASCADE)
    user              = models.ForeignKey(User, related_name='updates',
                                          on_delete=models.CASCADE)
    update_text       = models.TextField()
    plan_for_tomorrow = models.TextField()
    date              = models.DateField(default=timezone.now)

    class Meta:
        unique_together = ('task', 'user', 'date')
        ordering        = ['-date']

    def __str__(self):
        return f"Update {self.task_id} – {self.date}"
