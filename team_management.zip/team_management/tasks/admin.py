# In tasks/admin.py
from django.contrib import admin
from .models import Task, DailyUpdate

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ('title', 'assignee', 'status', 'due_date')
    list_filter = ('status', 'assignee')
    search_fields = ('title', 'description')

@admin.register(DailyUpdate)
class DailyUpdateAdmin(admin.ModelAdmin):
    list_display = ('task', 'user', 'date')
    list_filter = ('date', 'user')
