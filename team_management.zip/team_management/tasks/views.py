from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, CreateView, UpdateView, RedirectView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.utils import timezone
from django.db.models import Count, Q
from .models import Task, DailyUpdate
from accounts.models import Profile
from .forms import TaskForm, DailyUpdateForm

# ✅ HOME REDIRECT VIEW (Required for /tasks/)
class HomeRedirectView(LoginRequiredMixin, RedirectView):
    """
    Redirect /tasks/ URL to the appropriate dashboard based on the user's role.
    """
    permanent = False

    def get_redirect_url(self, *args, **kwargs):
        user = self.request.user
        if hasattr(user, 'profile') and getattr(user.profile, 'role', None) == 'manager':
            return '/tasks/manager/'
        return '/tasks/dashboard/'

# ✅ Task Management Dashboard - Focus on Task Operations
class TaskManagementView(LoginRequiredMixin, ListView):
    model = Task
    template_name = 'tasks/task_management_dashboard.html'
    context_object_name = 'tasks'
    paginate_by = 20

    def get_queryset(self):
        user = self.request.user
        if hasattr(user, 'profile') and user.profile.role == 'manager':
            return Task.objects.all().select_related('assignee', 'assignee__profile')
        else:
            return Task.objects.filter(assignee=user).select_related('assignee__profile')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        user = self.request.user

        qs = self.get_queryset()
        context.update({
            'view_type': 'task_management',
            'total_tasks': qs.count(),
            'task_stats': {
                'todo': qs.filter(status='todo').count(),
                'in_progress': qs.filter(status='prog').count(),
                'done': qs.filter(status='done').count(),
            },
            'can_edit_tasks': hasattr(user, 'profile') and user.profile.role == 'manager',
            'recent_updates': DailyUpdate.objects.filter(task__in=qs).order_by('-date')[:10],
        })
        return context

# ✅ Manager Dashboard - Focus on Team Management
class ManagerDashboardView(LoginRequiredMixin, ListView):
    model = Task
    template_name = 'tasks/manager_dashboard.html'
    context_object_name = 'tasks'

    def get_queryset(self):
        return Task.objects.all().select_related('assignee', 'assignee__profile')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        today = timezone.now().date()

        context.update({
            'view_type': 'manager_dashboard',
            'today_updates': DailyUpdate.objects.filter(date=today).select_related('user', 'task'),
            'team_stats': self.get_team_statistics(),
            'work_location_stats': self.get_work_location_stats(),
            'leave_stats': self.get_leave_statistics(),
            'task_assignment_stats': self.get_task_assignment_stats(),
            'productivity_metrics': self.get_productivity_metrics(),
        })
        return context

    def get_team_statistics(self):
        return {
            'total_team_members': Profile.objects.filter(role__in=['manager', 'personal']).count(),
            'active_members': Profile.objects.filter(
                role__in=['manager', 'personal'],
                user__is_active=True
            ).count(),
        }

    def get_work_location_stats(self):
        today = timezone.now().date()
        total_updates = DailyUpdate.objects.filter(date=today).count()
        return {
            'wfh_count': int(total_updates * 0.6),  # simulated data
            'office_count': int(total_updates * 0.4),
            'total_working': total_updates,
            'wfh_percentage': 60,
            'office_percentage': 40,
        }

    def get_leave_statistics(self):
        total_team = Profile.objects.filter(role__in=['manager', 'personal']).count()
        return {
            'on_leave_today': 2,  # simulated
            'planned_leaves': 5,
            'available_team': total_team - 2,
            'leave_requests_pending': 3,
        }

    def get_task_assignment_stats(self):
        return {
            'unassigned_tasks': Task.objects.filter(assignee__isnull=True).count(),
            'overdue_tasks': Task.objects.filter(
                due_date__lt=timezone.now().date(),
                status__in=['todo', 'prog']
            ).count(),
            'completed_this_week': Task.objects.filter(
                status='done',
                updated_at__gte=timezone.now() - timezone.timedelta(days=7)
            ).count(),
        }

    def get_productivity_metrics(self):
        today = timezone.now().date()
        submitted = DailyUpdate.objects.filter(date=today).count()
        expected = Profile.objects.filter(role='personal').count()
        return {
            'daily_updates_submitted': submitted,
            'expected_updates': expected,
            'update_submission_rate': min(100, int(submitted / max(1, expected) * 100)),
        }

# ✅ Personal Dashboard View (MISSING - This fixes your current error)
class PersonalDashboardView(LoginRequiredMixin, ListView):
    model = Task
    template_name = 'tasks/personal_dashboard.html'
    context_object_name = 'tasks'

    def get_queryset(self):
        # Show only tasks assigned to the current logged-in user
        return Task.objects.filter(assignee=self.request.user).order_by('due_date')

# ✅ Task Creation View (needed for /tasks/add/)
class TaskCreateView(LoginRequiredMixin, CreateView):
    model = Task
    form_class = TaskForm
    template_name = 'tasks/task_form.html'
    success_url = reverse_lazy('tasks:manager_dashboard')

# ✅ Task Update View (needed for /tasks/<int:pk>/edit/)
class TaskUpdateView(LoginRequiredMixin, UpdateView):
    model = Task
    form_class = TaskForm
    template_name = 'tasks/task_form.html'
    success_url = reverse_lazy('tasks:manager_dashboard')

# ✅ Submit Daily Update Function (needed for daily status updates)
def submit_daily_update(request, task_id):
    task = get_object_or_404(Task, id=task_id, assignee=request.user)
    
    # Check if an update for this task already exists today
    today = timezone.now().date()
    instance = DailyUpdate.objects.filter(task=task, user=request.user, date=today).first()

    if request.method == 'POST':
        form = DailyUpdateForm(request.POST, instance=instance)
        if form.is_valid():
            update = form.save(commit=False)
            update.task = task
            update.user = request.user
            update.date = today
            update.save()
            return redirect('tasks:personal_dashboard')
    else:
        form = DailyUpdateForm(instance=instance)

    return render(request, 'tasks/dailyupdate_form.html', {'form': form, 'task': task})
