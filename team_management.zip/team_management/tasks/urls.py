from django.urls import path
from . import views

app_name = 'tasks'

urlpatterns = [
    # Root redirect
    path('', views.HomeRedirectView.as_view(), name='home'),
    
    # Differentiated Dashboard URLs
    path('management/', views.TaskManagementView.as_view(), name='task_management'),
    path('manager/', views.ManagerDashboardView.as_view(), name='manager_dashboard'),
    
    # Task CRUD Operations
    path('add/', views.TaskCreateView.as_view(), name='task_create'),
    path('<int:pk>/edit/', views.TaskUpdateView.as_view(), name='edit'),
    
    # Personal User URLs
    path('dashboard/', views.PersonalDashboardView.as_view(), name='personal_dashboard'),
    path('update/<int:task_id>/', views.submit_daily_update, name='submit_update'),
]
