from django import forms
from .models import Task, DailyUpdate


class TaskForm(forms.ModelForm):
    """
    Form used by managers to create / edit tasks.
    Includes all new business fields (function_name, task_type, etc.)
    and styles every widget with Bootstrap-5 classes.
    """
    class Meta:
        model = Task
        fields = [
            'function_name',         # Function Name
            'task_type',             # Task Type
            'collab_responsible',    # Collab Responsible
            'total_fts',             # Total No of FT's
            'completed_fts',         # No of FT's Completed
            'assignee',              # Task owner
            'status',                # Task Status
            'start_date',            # Start Date
            'delivery_date',         # Delivery Date
            'remarks',               # Remarks / Comments
        ]
        widgets = {
            'function_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter function name'
            }),
            'task_type': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'e.g., Bug, Feature, Enhancement'
            }),
            'collab_responsible': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Team or person responsible'
            }),
            'total_fts': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 0
            }),
            'completed_fts': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 0
            }),
            'assignee': forms.Select(attrs={
                'class': 'form-select'
            }),
            'status': forms.Select(attrs={
                'class': 'form-select'
            }),
            'start_date': forms.DateInput(attrs={
                'type': 'date',
                'class': 'form-control'
            }),
            'delivery_date': forms.DateInput(attrs={
                'type': 'date',
                'class': 'form-control'
            }),
            'remarks': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Add any remarks or comments'
            }),
        }


class DailyUpdateForm(forms.ModelForm):
    """
    Form used by individual contributors to log daily progress / next-steps.
    """
    class Meta:
        model = DailyUpdate
        fields = ['update_text', 'plan_for_tomorrow']
        widgets = {
            'update_text': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Describe your progress...'
            }),
            'plan_for_tomorrow': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Describe your next steps...'
            }),
        }
