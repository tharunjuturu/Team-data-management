from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import TemplateView

@login_required
def home_dashboard(request):
    """
    Main home dashboard that shows navigation options based on user role
    """
    user = request.user
    user_role = 'unknown'
    user_team = 'No Team'
    
    # Get user role and team information
    if hasattr(user, 'profile'):
        user_role = user.profile.role
        user_team = user.profile.team or 'No Team'
    
    # Get some basic statistics for the dashboard
    context = {
        'user': user,
        'user_role': user_role,
        'user_team': user_team,
    }
    
    # Add role-specific statistics
    if user_role == 'manager':
        from tasks.models import Task, DailyUpdate
        from django.utils import timezone
        today = timezone.now().date()
        
        context.update({
            'total_tasks': Task.objects.count(),
            'pending_tasks': Task.objects.filter(status='todo').count(),
            'completed_tasks': Task.objects.filter(status='done').count(),
            'today_updates': DailyUpdate.objects.filter(date=today).count(),
        })
    elif user_role == 'personal':
        from tasks.models import Task, DailyUpdate
        from django.utils import timezone
        today = timezone.now().date()
        
        context.update({
            'my_tasks': Task.objects.filter(assignee=user).count(),
            'my_pending': Task.objects.filter(assignee=user, status='todo').count(),
            'my_completed': Task.objects.filter(assignee=user, status='done').count(),
            'my_today_updates': DailyUpdate.objects.filter(user=user, date=today).count(),
        })
    
    return render(request, 'home_dashboard.html', context)

# Keep this for backward compatibility
def home_redirect(request):
    """
    Legacy redirect function - now points to the dashboard
    """
    if not request.user.is_authenticated:
        return redirect('/accounts/login/')
    return redirect('home_dashboard')
