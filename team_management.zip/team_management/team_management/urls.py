from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('accounts.urls')),
    path('tasks/', include('tasks.urls')),
    path('', views.home_dashboard, name='home_dashboard'),  # New home dashboard
    path('redirect/', views.home_redirect, name='home'),    # Keep for compatibility
    path('dashboard/', lambda request: redirect('/tasks/dashboard/'), name='dashboard_alias'),
]

